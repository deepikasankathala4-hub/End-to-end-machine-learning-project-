# Task 4 — End-to-End Student Pass/Fail Prediction

## Project
An educational classification project comparing Logistic Regression and Random Forest to predict student pass/fail outcomes.

## Files
- `Task4_End_to_End_Student_Performance_Project.ipynb` — complete project notebook
- `Project_Report.md` — report template and project explanation
- `requirements.txt` — Python libraries used

## Dataset
Starter dataset: UCI Student Performance dataset (Mathematics file).
Source: https://archive.ics.uci.edu/dataset/320/student+performance

**Important:** The internship instructions say to use the dataset prepared in Week 2. If your Week 2 dataset is different, replace the notebook's loading section with your cleaned CSV and adapt the target/features accordingly.

## How to Run
1. Open https://colab.research.google.com/
2. Upload the `.ipynb` file.
3. Run all cells from top to bottom.
4. Internet access is needed for the automatic dataset download.
5. After execution, copy the actual evaluation values into the report and save the notebook with outputs.
6. Submit the notebook, dataset, report, README, and screenshots as requested.

## Models and metrics
- Logistic Regression
- Random Forest
- Accuracy, precision, recall, F1-score, and confusion matrix

## Responsible use
This project is for learning purposes only. Do not use its predictions as the sole basis for real decisions about individual students.
